# Rental Home Project Instructions

## Core rule

`AGENTS.md` in the protected base is the project-specific source of truth.
Do not add extra process unless required by `AGENTS.md`, the canonical core
policy, this extension, or the user.

## Language

Use English for repository artifacts unless the task requires Vietnamese.
Keep technical terms such as spec, workflow, PR, validation, RLS, Supabase,
Figma, and Mermaid unchanged.

## Session and branch rule

- One unique session directory per task.
- One isolated worktree/folder per branch.
- Do not reuse a worktree for another branch.
- Keep proposal, logs, screenshots, diagrams, and reports inside the session
  directory.

## Required task context

Before implementation, identify:

- repository;
- base branch and full base SHA;
- dedicated working branch;
- task/spec identifier;
- required frontend, backend, UI, database, or testing skills;
- location of requirements, design, tasks, conventions, and acceptance criteria;
- affected data entities, RLS policies, APIs, screens, and workflows;
- validation commands discovered from the protected base.

## Repository connector policy

GitHub Connector is the primary repository connector for Rental Home.

A repository write may proceed only when all of these are true:

1. The active profile is `rental-home` and `write_enabled` is `true`.
2. Repository identity resolves exactly to
   `nhatnguyenquang1838-coder/rental_home`.
3. The connector has verified access to the expected repository and branch.
4. The current base and head SHA match the scoped approval envelope.
5. Policy enforcement passes immediately before the write.

DW Connector is a conditional fallback, not an independent authority source.
Use DW only when GitHub Connector is unavailable or lacks a required supported
action, and only after DW independently verifies the same repository identity,
branch, expected SHA, and write permission.

Fallback must stop rather than write when:

- connector identity is ambiguous;
- repository, branch, or SHA differs from the approval envelope;
- the fallback would broaden files, modules, or actions;
- the fallback requires force-push, protected-branch write, merge, deployment,
  configuration, credential, migration, or production-data authority;
- policy enforcement is not `PASS`.

Connector failure does not weaken approval, scope, or gate requirements.
A successful connector call is evidence only; it never grants authority.

## E2E Draft PR delivery gate

When the user activates `DELIVER_E2E_PR`, a valid `G2_EXECUTION` envelope may
authorize implementation, validation, push to the approved working branch, and
creation or update of a Draft PR.

The gate remains fail-closed unless the active profile, repository identity,
connector, exact approval token, base SHA, branch, file scope, artifact hashes,
and expiry all validate.

`G2_EXECUTION` never authorizes merge, auto-merge, release, deployment,
production configuration, credentials, migration, or production-data access.
Those actions require their separate authority gates.

## Delivery

Use Draft Pull Requests for reviewed delivery. Do not merge or deploy without
separate authority. Record:

- changed files;
- behavior;
- tests;
- validation;
- screenshots or visual evidence when UI changes;
- migration and configuration status;
- residual risks.
