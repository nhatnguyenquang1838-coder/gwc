# Rental Home Agent Entry

This repository is governed by GWC.

## Source instruction

Repository evidence wins over conversation memory. If sources conflict, follow the highest-priority active GWC source unless this repository's protected-base `AGENTS.md` is stricter.

For non-trivial repository, PR, review, docs, orchestration, configuration, deployment, or production-data work, agents must start with:

```text
SOURCE INSTRUCTION: <GDRIVE|GIT|GPT_PROJECT|REPO|PACKAGE|MIXED>
EXECUTION MODE: <chat_connector_only|local_agent|repo_ci>
```

## Required boot order

Before repository-changing work, read:

```text
1. AGENTS.md
2. .gwc/gwc/AGENTS.md or .governance/AGENTS.md when present
3. .gwc/gwc/core/Coding_Project_Governance_v1.0.md or .governance/Coding_Project_Governance_v1.0.md
4. .gwc/gwc/core/GATE_LIFECYCLE_CONTRACT_v1.0.md or .governance/GATE_LIFECYCLE_CONTRACT_v1.0.md
5. .gwc/gwc/core/Agent_Operating_Runtime_Contract_v1.0.md or .governance/Agent_Operating_Runtime_Contract_v1.0.md
6. .gwc/gwc/core/E2E_DRAFT_PR_DELIVERY_RULE.md or .governance/E2E_DRAFT_PR_DELIVERY_RULE.md
7. .gwc/gwc/core/runbooks/GATE_G0_G1_OPERATIONAL_RUNBOOK_v1.0.md or .governance/GATE_G0_G1_OPERATIONAL_RUNBOOK_v1.0.md
8. .gwc/gwc/core/LOCAL_AGENT_RULE.md or .governance/LOCAL_AGENT_RULE.md
9. applicable .gwc/gwc/agents/<agent>/agent-instructions.md and capability declaration
10. .gwc/gwc/governance/instruction-source-registry.yaml or .governance/instruction-source-registry.yaml when present
11. .gwc/gwc/projects/rental-home/project-profile.yaml or .governance/project-profile.yaml
12. .gwc/gwc/projects/rental-home/project-instructions.md or .governance/project-instructions.md
13. .gwc/gwc/projects/rental-home/project-extension.md or .governance/project-extension.md
14. .gwc/gwc/projects/rental-home/spec-driven-format.md or .governance/spec-driven-format.md
15. package.json and lockfiles
16. task/spec/workflow/source files relevant to the request
```

If `.gwc/gwc` is expected but cannot be loaded, use `.governance` as a generated-package fallback. If both are missing or stale for the requested action, fail closed for repository-changing work.

## Mandatory repository state claim

Before making a content-dependent recommendation or invoking a write-capable action, report the current state of both the Rental Home checkout and its GWC submodule. Do not infer state from memory, a prior turn, or a different worktree.

The claim must include:

```text
RENTAL_HOME_STATE:
  path: <absolute checkout path>
  branch: <branch name or DETACHED>
  head_sha: <40-character SHA>
  upstream_main_sha: <40-character SHA or UNAVAILABLE>
  working_tree: CLEAN | DIRTY | UNAVAILABLE

GWC_SUBMODULE_STATE:
  path: <checkout>/.gwc/gwc
  branch: <branch name or DETACHED>
  head_sha: <40-character SHA>
  working_tree: CLEAN | DIRTY | UNINITIALIZED | MISSING
  superproject_gitlink: <40-character SHA>
```

If either checkout is missing, uninitialized, dirty, or inconsistent with the requested action, stop and refresh the evidence before continuing. A detached GWC submodule is normal when it matches the superproject gitlink and is explicitly reported as `DETACHED`.

## User-facing G0/G1 reporting

After G0/G1 artifacts are generated and validated, keep the chat handoff lightweight. Report the gate status, a concise human-readable summary, and one Markdown link to the full proposal. Keep YAML, Mermaid, SVG, PNG, hashes, and validator output in the isolated session package; do not paste them into chat by default. Render additional visual detail inline only when the user requests it or the relationship cannot be understood from the short summary.

The full proposal package must still contain the canonical G0/G1 artifacts and required offline visuals. A session-local generator may produce the predefined Markdown and visual files from the structured YAML, but adding such a generator to this repository requires its own scope and approval.

## Intake Card

Before repository-changing work, produce an Intake Card with:

```text
Request Type:
Source Instruction:
Execution Mode:
Risk Flags:
Required Reads:
Files READ:
Files WRITE:
Gate Required:
Next Action:
```

## Files READ / Files WRITE

```text
No Files READ evidence -> no content-dependent recommendation.
No Files WRITE declaration -> no repository mutation.
New write path -> stop, update scope, regenerate approval request.
Actual write outside approved scope -> scope drift, stop before commit or PR.
```

Every delivery must report:

```text
Files READ actual:
Files WRITE actual:
Scope drift: NONE | DETECTED
```

## Gate lifecycle

Follow the GWC gate sequence:

```text
G0_CONTEXT
→ G1_ALIGNMENT
→ G2_EXECUTION
→ G3_PR
→ G4_MERGE
→ G5_DEPLOY
→ G6_PRODUCTION_DATA
```

Do not skip gates. Do not backfill gate evidence after action.

## Approval commands

Humans do not create approval tokens, scope hashes, artifact IDs, branch names, file scopes, or expiry values.

The agent must generate the approval request and exact command. The human grants authority only by copy-pasting the exact generated command:

```text
APPROVE <GATE> <approval_request_id> <scope_hash_16> <expires_at_utc>
```

Plain phrases such as `ok`, `approve`, `approved`, `continue`, `go`, `yes`, `làm đi`, or `fix ngay` are acknowledgement-only and never grant gate authority unless they exactly match an active generated approval command.

## Repository rules

```text
Use a separate worktree/folder per branch.
Never edit main directly.
Do not touch production data/config/secrets.
Do not weaken Supabase RLS/auth/privacy.
Do not add database migrations unless explicitly scoped and gated.
Open Draft PR only after validation evidence exists or clearly report skipped validation.
User reviews after CI passes.
Merge/deploy only by separate human authority.
```

## Safety boundary

G2 never authorizes merge, deployment, production configuration, credentials, migration, or production-data access. Those require G4, G5, or G6 authority for the exact operation.

If `.gwc/gwc` is missing, follow:

```text
docs/GWC_SUBMODULE_SETUP.md
```
