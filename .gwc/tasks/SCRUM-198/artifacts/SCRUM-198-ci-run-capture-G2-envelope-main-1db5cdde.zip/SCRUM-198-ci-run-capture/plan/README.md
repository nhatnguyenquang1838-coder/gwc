# SCRUM-198 — repo_delivery.ci-run-capture

## User story

As a delivery agent, I want CI state captured for the exact PR head and workflow attempt so that G3 never relies on stale, ambiguous or projection-only status.

## Objective

Create a deterministic, exact-head CI observation adapter with terminal/non-terminal taxonomy and resumable polling.

## EARS acceptance requirements

1. The system shall bind every CI observation to repository, PR, branch, exact head SHA, workflow run ID, workflow name, attempt, event, status, conclusion and observation timestamp.
2. When CI is non-terminal, the system shall persist the current observation and continuation checkpoint before waiting for the next check.
3. When the observed head SHA differs from the current PR head SHA, the system shall invalidate the observation and shall restart capture for the new head.
4. When the connector returns no result and exact filtering is unsupported, the system shall classify the observation as CI_UNAVAILABLE_AT_CHECK or CONNECTOR_OBSERVABILITY_INCOMPLETE rather than CI_PENDING.
5. When multiple agents poll the same run, the system shall use a stable observation key and shall not advance the runtime twice for the same logical CI state.
6. If a timeout occurs, the system shall route to failure_recovery.timeout-recovery without assuming the CI run failed.

## Dependency

- Wave: `W2`
- Depends on: SCRUM-203
- Target: `M5_REPLAY_SAFE`
