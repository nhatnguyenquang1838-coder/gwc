# Impact Analysis

- Runtime family: `repo_delivery`
- Upstream dependencies: SCRUM-203
- Downstream consumers: SCRUM-238, SCRUM-214
- Shared concerns: exact SHA, scope hash, event history, checkpoint, idempotency, replay, source authority.
- Highest risk: high.
