# Test Plan

- pending/passed/failed/cancelled/unavailable taxonomy
- exact-head and attempt binding
- head drift invalidation
- duplicate poller fencing
- connector-empty fallback classification

## Mandatory global tests

- crash at every state boundary
- duplicate agent / stale worker
- exact-head and scope drift
- replay produces same state and decision
- projection-only evidence rejected
