# Implementation Plan

1. Verify current repository implementation and exact target paths at formal G0/G1.
2. Normalize the node ID and register backward-compatible aliases where required.
3. Define versioned input, output, reason-code, authority and evidence schemas.
4. Implement a deterministic core separated from provider/connector adapters.
5. Add checkpoint, idempotency, CAS/fencing and readback behavior appropriate to the node.
6. Add unit, contract, integration, crash, replay, drift and negative-authority tests.
7. Bind the node into the P0 scenario graph and generated runbook.
8. Run exact-head CI; after each CI-dependent node/gate, record a +2 minute scheduled recheck and continue active polling.
9. Capture evidence and update Jira only as projection.
