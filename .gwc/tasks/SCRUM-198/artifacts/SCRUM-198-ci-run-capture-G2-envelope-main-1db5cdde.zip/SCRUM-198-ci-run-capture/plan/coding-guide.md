# Coding Guide

## Candidate paths — verify before G2

- `core/node-architect/node-catalog/repo_delivery/ci-run-capture.node.json`
- `schemas/ci-observation.schema.json`
- `tools/node_architect/ci_run_capture.py`
- `tests/test_ci_run_capture_replay.py`

## Design constraints

- Keep provider I/O at the adapter boundary; make classification and decision logic pure where possible.
- Emit append-only events before treating progress as replayable.
- Use stable identities derived from task, exact SHA, node/version and logical attempt.
- Never infer PASS from provider success without canonical readback.
- Preserve G2/G3/G4/G5/G6 separation.
