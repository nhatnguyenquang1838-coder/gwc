# Worker Quick Prompt — SCRUM-198

SOURCE INSTRUCTION: REPO
EXECUTION MODE: choose from verified capabilities

Repository: nhatnguyenquang1838-coder/gwc
Task: SCRUM-198 — repo_delivery.ci-run-capture
Coordination task: SCRUM-256
Protected base: main@1db5cdde7666e95e0a5d864633a3255a2a6ad40e
Working branch: codex/scrum-198-ci-run-capture-m5-20260730
Target maturity: M5_REPLAY_SAFE
G2 approval ID: CP-20260730-198-G2-R2
Scope hash: 529f545593c9dc03feabd1d823eecf6675d426d18ac254bc7cc1b1fd163e909b
Dependency condition: Must verify these dependencies before activation: SCRUM-203

Read first:
1. Repository `AGENTS.md`.
2. Applicable governance contracts and `projects/gwc/project-profile.yaml`.
3. `plan/README.md`, `plan/task.yaml`, implementation plan, coding guide and test plan.
4. `.gwc/tasks/SCRUM-198/g2/execution-envelope.yaml`.

Before any repository write:
1. Recover current `main` and verify it still equals `1db5cdde7666e95e0a5d864633a3255a2a6ad40e`.
2. Materialize task-scoped G0/G1 artifacts under `.gwc/tasks/SCRUM-198/`.
3. Run the repository G0/G1 validator and require PASS.
4. Verify the exact unexpired approval command:
   `APPROVE G2_EXECUTION CP-20260730-198-G2-R2 529f545593c9dc03 2026-07-31T10:15:00Z`
5. Verify dependencies and record a plan-read receipt.
6. Create only branch `codex/scrum-198-ci-run-capture-m5-20260730` from the exact approved base.

Execute only the approved module list. Implement the smallest compatible change using
Reuse → Extend → Refactor → Replace. Run scoped validator and tests, inspect the complete
diff, push the guarded branch, and stop at G2 exit. Do not create a Draft PR until G3
artifacts and authority are ready.

Never merge, deploy, publish, change production/configuration/data/secrets, force-push,
delete branches, rewrite history, change PR base, expand scope or perform unrelated cleanup.
