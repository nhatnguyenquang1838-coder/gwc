# SCRUM-214 — Materialize exact-head CI evidence

## Status

- Planning/handoff: **READY**
- Formal G0/G1: **NOT YET VALIDATED**
- G2 envelope: **PREPARED / PENDING HUMAN APPROVAL**
- G2 execution authority: **INACTIVE**
- Base: `main@1db5cdde7666e95e0a5d864633a3255a2a6ad40e`
- Branch: `codex/scrum-214-ci-evidence-capture-m5-20260730`
- Target: `M5_REPLAY_SAFE`

## Dependency

Must verify these dependencies before activation: SCRUM-203, SCRUM-198, SCRUM-238

## Contents

- `.gwc/tasks/SCRUM-214/g2/execution-envelope.yaml`
- `approval/APPROVAL-COMMAND.txt`
- `approval/scope-hash-input.json`
- `plan/` — UA + Task-Me + BMAD-derived task plan
- `WORKER-QUICK-PROMPT.md`
- `evidence/session-inventory.json`

## Activation boundary

The package is ready for a worker to perform protected-base readback and formal G0/G1
materialization. It is not permission to write. The worker may enter G2 only after the
repository validator passes and the exact approval command is supplied.
