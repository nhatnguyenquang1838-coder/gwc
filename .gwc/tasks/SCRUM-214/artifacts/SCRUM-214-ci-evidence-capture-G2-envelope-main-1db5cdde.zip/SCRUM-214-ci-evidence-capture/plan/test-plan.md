# Test Plan

- terminal/non-terminal evidence states
- exact-head and source reference binding
- replay-stable hash
- missing job/artifact classification
- stale evidence invalidation

## Mandatory global tests

- crash at every state boundary
- duplicate agent / stale worker
- exact-head and scope drift
- replay produces same state and decision
- projection-only evidence rejected
