# Observable Decisions

- **Evidence used:** Jira task, exact-SHA node descriptor, runtime kernel, gate lifecycle, interrupt contract.
- **Alternative considered:** implement all six nodes in Jira order.
- **Rule applied:** build durable shared dependencies before consumers; catalog order is not execution order.
- **Decision:** assign `SCRUM-214` to `W3` with dependencies `SCRUM-198, SCRUM-203, SCRUM-238`.
- **Confidence:** medium-high for architecture; medium for file-level scope until formal G0/G1.
- **Unresolved:** exact implementation modules, existing reusable symbols, and final scope hash.
