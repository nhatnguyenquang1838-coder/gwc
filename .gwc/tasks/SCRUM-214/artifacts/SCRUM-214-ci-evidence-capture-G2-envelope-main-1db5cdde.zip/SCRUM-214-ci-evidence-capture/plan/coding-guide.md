# Coding Guide

## Candidate paths — verify before G2

- `core/node-architect/node-catalog/validation_quality/ci-evidence-capture.node.json`
- `schemas/ci-evidence.schema.json`
- `tools/node_architect/ci_evidence_capture.py`
- `tests/test_ci_evidence_capture_replay.py`

## Design constraints

- Keep provider I/O at the adapter boundary; make classification and decision logic pure where possible.
- Emit append-only events before treating progress as replayable.
- Use stable identities derived from task, exact SHA, node/version and logical attempt.
- Never infer PASS from provider success without canonical readback.
- Preserve G2/G3/G4/G5/G6 separation.
