# Impact Analysis

- Runtime family: `validation_quality`
- Upstream dependencies: SCRUM-198, SCRUM-203, SCRUM-238
- Downstream consumers: SCRUM-215, SCRUM-219
- Shared concerns: exact SHA, scope hash, event history, checkpoint, idempotency, replay, source authority.
- Highest risk: high.
