# SCRUM-214 — validation_quality.ci-evidence-capture

## User story

As a G3 reviewer, I want normalized CI evidence tied to the exact delivery head so that the quality decision can be reproduced and audited independently.

## Objective

Transform CI observations into immutable, exact-head evidence records that can survive crash, replay and head drift.

## EARS acceptance requirements

1. The system shall materialize CI evidence with exact head SHA, run/job IDs, attempt, checks, conclusions, timestamps, source references and evidence hash.
2. When CI is non-terminal, the system shall record a non-terminal evidence state and shall not mark the evidence bundle complete.
3. When CI reaches a terminal state, the system shall read back the latest run and job state before finalizing the evidence record.
4. When the PR head changes after capture, the system shall mark the prior evidence stale and shall require recapture for the new head.
5. When evidence materialization is replayed with the same input set, the system shall produce the same evidence identity and content hash.
6. If required jobs, artifacts or source references are missing, the system shall emit typed missing-evidence reasons and shall not silently downgrade requirements.

## Dependency

- Wave: `W3`
- Depends on: SCRUM-198, SCRUM-203, SCRUM-238
- Target: `M5_REPLAY_SAFE`
