# Worker Quick Prompt — SCRUM-214

SOURCE INSTRUCTION: REPO
EXECUTION MODE: choose from verified capabilities

Repository: nhatnguyenquang1838-coder/gwc
Task: SCRUM-214 — validation_quality.ci-evidence-capture
Coordination task: SCRUM-256
Protected base: main@1db5cdde7666e95e0a5d864633a3255a2a6ad40e
Working branch: codex/scrum-214-ci-evidence-capture-m5-20260730
Target maturity: M5_REPLAY_SAFE
G2 approval ID: CP-20260730-214-G2-R2
Scope hash: 021eb76b5cd9d49c6f3a37765e6750663ee4d2a84bdfe4c0c21326f566ee1a13
Dependency condition: Must verify these dependencies before activation: SCRUM-203, SCRUM-198, SCRUM-238

Read first:
1. Repository `AGENTS.md`.
2. Applicable governance contracts and `projects/gwc/project-profile.yaml`.
3. `plan/README.md`, `plan/task.yaml`, implementation plan, coding guide and test plan.
4. `.gwc/tasks/SCRUM-214/g2/execution-envelope.yaml`.

Before any repository write:
1. Recover current `main` and verify it still equals `1db5cdde7666e95e0a5d864633a3255a2a6ad40e`.
2. Materialize task-scoped G0/G1 artifacts under `.gwc/tasks/SCRUM-214/`.
3. Run the repository G0/G1 validator and require PASS.
4. Verify the exact unexpired approval command:
   `APPROVE G2_EXECUTION CP-20260730-214-G2-R2 021eb76b5cd9d49c 2026-07-31T10:15:00Z`
5. Verify dependencies and record a plan-read receipt.
6. Create only branch `codex/scrum-214-ci-evidence-capture-m5-20260730` from the exact approved base.

Execute only the approved module list. Implement the smallest compatible change using
Reuse → Extend → Refactor → Replace. Run scoped validator and tests, inspect the complete
diff, push the guarded branch, and stop at G2 exit. Do not create a Draft PR until G3
artifacts and authority are ready.

Never merge, deploy, publish, change production/configuration/data/secrets, force-push,
delete branches, rewrite history, change PR base, expand scope or perform unrelated cleanup.
