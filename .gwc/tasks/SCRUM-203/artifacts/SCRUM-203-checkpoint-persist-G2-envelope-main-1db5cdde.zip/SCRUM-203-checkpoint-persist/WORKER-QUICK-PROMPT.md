# Worker Quick Prompt — SCRUM-203

SOURCE INSTRUCTION: REPO
EXECUTION MODE: choose from verified capabilities

Repository: nhatnguyenquang1838-coder/gwc
Task: SCRUM-203 — runtime_checkpoint.checkpoint-persist
Coordination task: SCRUM-256
Protected base: main@1db5cdde7666e95e0a5d864633a3255a2a6ad40e
Working branch: codex/scrum-203-checkpoint-persist-m5-20260730
Target maturity: M5_REPLAY_SAFE
G2 approval ID: CP-20260730-203-G2-R2
Scope hash: 9b3abdcf5929996c4208219fa7d23ae7f59a84d270293ea3d72aa46d8b4da907
Dependency condition: None. This is the first implementation wave.

Read first:
1. Repository `AGENTS.md`.
2. Applicable governance contracts and `projects/gwc/project-profile.yaml`.
3. `plan/README.md`, `plan/task.yaml`, implementation plan, coding guide and test plan.
4. `.gwc/tasks/SCRUM-203/g2/execution-envelope.yaml`.

Before any repository write:
1. Recover current `main` and verify it still equals `1db5cdde7666e95e0a5d864633a3255a2a6ad40e`.
2. Materialize task-scoped G0/G1 artifacts under `.gwc/tasks/SCRUM-203/`.
3. Run the repository G0/G1 validator and require PASS.
4. Verify the exact unexpired approval command:
   `APPROVE G2_EXECUTION CP-20260730-203-G2-R2 9b3abdcf5929996c 2026-07-31T10:15:00Z`
5. Verify dependencies and record a plan-read receipt.
6. Create only branch `codex/scrum-203-checkpoint-persist-m5-20260730` from the exact approved base.

Execute only the approved module list. Implement the smallest compatible change using
Reuse → Extend → Refactor → Replace. Run scoped validator and tests, inspect the complete
diff, push the guarded branch, and stop at G2 exit. Do not create a Draft PR until G3
artifacts and authority are ready.

Never merge, deploy, publish, change production/configuration/data/secrets, force-push,
delete branches, rewrite history, change PR base, expand scope or perform unrelated cleanup.
