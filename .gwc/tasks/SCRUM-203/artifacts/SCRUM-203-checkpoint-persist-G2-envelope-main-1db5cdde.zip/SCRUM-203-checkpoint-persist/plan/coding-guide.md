# Coding Guide

## Candidate paths — verify before G2

- `core/node-architect/node-catalog/runtime_checkpoint/checkpoint-persist.node.json`
- `schemas/runtime-checkpoint.schema.json`
- `schemas/runtime-event.schema.json`
- `tools/node_architect/checkpoint_store.py`
- `tests/test_checkpoint_persist_replay.py`

## Design constraints

- Keep provider I/O at the adapter boundary; make classification and decision logic pure where possible.
- Emit append-only events before treating progress as replayable.
- Use stable identities derived from task, exact SHA, node/version and logical attempt.
- Never infer PASS from provider success without canonical readback.
- Preserve G2/G3/G4/G5/G6 separation.
