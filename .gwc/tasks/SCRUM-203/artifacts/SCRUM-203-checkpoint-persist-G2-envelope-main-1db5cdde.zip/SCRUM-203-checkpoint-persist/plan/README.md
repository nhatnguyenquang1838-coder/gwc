# SCRUM-203 — runtime_checkpoint.checkpoint-persist

## User story

As a GWC runtime operator, I want every suspend, wait, crash and resume point persisted atomically so that an interrupted run can continue without stale writes or duplicated side effects.

## Objective

Establish the durable checkpoint, event-history, CAS, version-pin and pending-action foundation used by every other node in the slice.

## EARS acceptance requirements

1. The system shall persist each checkpoint with task ID, run ID, node ID/version, graph revision, gate, exact repository/base/head bindings, scope hash, next action and evidence references.
2. When a node is about to wait, hand off, call an unavailable connector or request human authority, the system shall persist a checkpoint before changing the node to a suspended state.
3. When the expected checkpoint revision differs from the stored revision, the system shall reject the write with CAS_MISMATCH and shall reload canonical state before any retry.
4. When a checkpoint write succeeds but the agent crashes before acknowledgement, the system shall read back the stored revision and shall not create a duplicate logical checkpoint.
5. While a pending action has an unknown external outcome, the system shall preserve the pending-action record and shall require reconciliation before re-execution.
6. If node pack, graph revision, task, gate, scope, base SHA, head SHA or approval binding drifts, the system shall block resume and emit a typed revalidation or reapproval route.

## Dependency

- Wave: `W1`
- Depends on: W0 shared contracts only
- Target: `M5_REPLAY_SAFE`
