# Impact Analysis

- Runtime family: `runtime_checkpoint`
- Upstream dependencies: shared contracts
- Downstream consumers: SCRUM-198, SCRUM-238, SCRUM-214
- Shared concerns: exact SHA, scope hash, event history, checkpoint, idempotency, replay, source authority.
- Highest risk: high.
