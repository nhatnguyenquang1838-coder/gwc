# Observable Decisions

- **Evidence used:** Jira task, exact-SHA node descriptor, runtime kernel, gate lifecycle, interrupt contract.
- **Alternative considered:** implement all six nodes in Jira order.
- **Rule applied:** build durable shared dependencies before consumers; catalog order is not execution order.
- **Decision:** assign `SCRUM-203` to `W1` with dependencies `W0`.
- **Confidence:** medium-high for architecture; medium for file-level scope until formal G0/G1.
- **Unresolved:** exact implementation modules, existing reusable symbols, and final scope hash.
