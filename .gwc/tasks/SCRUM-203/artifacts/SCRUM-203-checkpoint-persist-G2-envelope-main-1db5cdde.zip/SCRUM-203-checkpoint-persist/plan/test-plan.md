# Test Plan

- CAS success and mismatch concurrency tests
- crash-before-write / crash-after-commit replay tests
- pending-action reconciliation tests
- version and exact-SHA drift rejection tests
- event-history replay produces the same checkpoint state

## Mandatory global tests

- crash at every state boundary
- duplicate agent / stale worker
- exact-head and scope drift
- replay produces same state and decision
- projection-only evidence rejected
